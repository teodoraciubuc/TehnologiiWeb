const About = () => {
  return (
    <>
      <h2>About</h2>
      <p>Aici este pagina About.</p>
    </>
  )
}

export default About