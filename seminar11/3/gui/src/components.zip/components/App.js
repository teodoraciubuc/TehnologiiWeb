import UserList from './UserList'

function App() {
  return (
    <div>
      <h1>A user app</h1>
      <UserList/>
    </div>
  )
}
export default App;
