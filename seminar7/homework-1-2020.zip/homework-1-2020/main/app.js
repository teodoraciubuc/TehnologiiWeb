const distance = (a, b) => {
  if (typeof a !== "string" || typeof b !== "string") {
    throw new Error("InvalidType");
  }

  if (a === "" && b === "") {
    return 0;
  }

  if (a[0] !== b[0]) {
    a = a.slice(1);
    b = b.slice(1);
  }

  const setA = new Set(a);
  const setB = new Set(b);

  let diff = 0;
  for (const charA of setA) {
    const existaInB = setB.has(charA);
    if (!existaInB) {
      diff = diff + 1;
    }
  }

  for (const charB of setB) {
    const existaInA = setA.has(charB);
    if (!existaInA) {
      diff = diff + 1;
    }
  }

  return diff;
};

module.exports.distance = distance;
